package com.ust;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class Test {
	//spring rest consumer class to consume the endpoint urls
	public static void main(String[] args) {
		RestTemplate rt =new RestTemplate();
		String url="http://localhost:8000/SpringDemoOnRestFul/mvc/ec/show";
		
		//http method
		ResponseEntity<String> re=rt.getForEntity(url, String.class);
		System.out.println("body is "+re.getBody());
		System.out.println("status code is "+re.getStatusCode());
		System.out.println(re.getHeaders());
	}

}
