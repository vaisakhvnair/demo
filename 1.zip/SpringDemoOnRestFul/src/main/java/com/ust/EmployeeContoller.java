package com.ust;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Employee;

@RestController
@RequestMapping("/ec")
public class EmployeeContoller {

	// HttpMethod + Method URL
	@GetMapping("/show")
	public ResponseEntity<String> showMsgA(){

		String body = "Welcome To GET Method Spring Rest Appication!!";
		HttpStatus status = HttpStatus.OK;
		ResponseEntity<String> entity = new ResponseEntity<String>(body,status);
		return entity;

	}
	@PostMapping("/show")
	public ResponseEntity<String> showMsgB(){

		String body = "Welcome To POST Method Spring Rest Appication!!";
		HttpStatus status = HttpStatus.OK;
		ResponseEntity<String> entity = new ResponseEntity<String>(body,status);

		return entity;
	}

	@PutMapping("/show")
	public ResponseEntity<String> showMsgC(){
		String body = "Welcome To PUT Method Spring Rest Appication!!";
		HttpStatus status = HttpStatus.OK;
		ResponseEntity<String> entity = new ResponseEntity<String>(body,status);
		return entity;
	}

	@DeleteMapping("/show")
	public ResponseEntity<String> showMsgD(){
		String body = "Welcome To DELETE Method Spring Rest Appication!!";
		HttpStatus status = HttpStatus.OK;
		ResponseEntity<String> entity = new ResponseEntity<String>(body,status);
		return entity;
	}

	@GetMapping("/gm/{m}")//{}-binding the path variable parameter
	public String getMessage(@PathVariable("m")String msg) {
		return "hello "+msg;
		
	}
	
	@PostMapping(value = "/add")	
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {
		System.out.println(emp.getEmpId()+" "+emp.getEmpname()+" "+emp.getEmpSal());
		
        ResponseEntity<Employee> entity= new ResponseEntity<Employee>(emp,HttpStatus.OK);
        return entity;
	}

	
	@PostMapping(value = "/insert",headers = "application/json ")
	public Employee getEmpDetails(@RequestBody Employee emp) {
		return emp;
		
	}




}
