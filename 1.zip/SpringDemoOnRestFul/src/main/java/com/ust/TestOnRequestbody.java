package com.ust;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ust.model.Employee;

public class TestOnRequestbody {

	
	public static void main(String[] args) {
		
		String body="<Employee><empId>1001</empId><empname>smit</empname><empSal>3000</empSal></Employee>";
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type","application/xml");
		headers.add("Accept","application/json");
		
		//headers.setContentType(MediaType.APPLICATION_XML);
		
		HttpEntity<String> hpn= new HttpEntity<String>(body,headers);
		
		RestTemplate rt = new RestTemplate();
		
		String url="http://localhost:8000/SpringDemoOnRestFul/mvc/ec/add";
		
		ResponseEntity<Employee> rsent=rt.postForEntity(url,hpn,Employee.class);
		System.out.println(rsent.getBody().getEmpId());
		System.out.println(rsent.getBody().getEmpname());
		System.out.println(rsent.getBody().getEmpSal());
		System.out.println(rsent.getBody());
		System.out.println(rsent.getStatusCode());
		System.out.println(rsent.getHeaders());
		
		
		
	}
}
